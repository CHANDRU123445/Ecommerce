package stepDefinition;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import java.util.List;

public class SearchStepDefinitions {
    WebDriver driver;

    @Given("I navigate to the Selenium Playground Table Search Demo page")
    public void navigateToSeleniumPlayground() {
        WebDriverManager.chromedriver().setup();  // Setting up WebDriver automatically
        driver = new ChromeDriver();
        driver.get("https://www.seleniumeasy.com/test/table-search-demo.html");
    }

    @When("I search for {string}")
    public void searchForText(String searchText) {
        WebElement searchBox = driver.findElement(By.id("task-table-filter"));
        searchBox.clear();
        searchBox.sendKeys(searchText);
    }

    @Then("I should see 5 results out of 24 total entries")
    public void validateSearchResults() {
        List<WebElement> results = driver.findElements(By.xpath("//table[@id='task-table']/tbody/tr"));
        Assert.assertEquals("Expected 5 entries, but found " + results.size(), 5, results.size());

        WebElement totalEntriesText = driver.findElement(By.xpath("//div[@class='col-sm-6 col-md-6']/label"));
        String totalText = totalEntriesText.getText();
        Assert.assertTrue("Expected 24 total entries, but found " + totalText, totalText.contains("24"));
    }

    @Then("I close the browser")
    public void closeBrowser() {
        driver.quit();
    }
}
