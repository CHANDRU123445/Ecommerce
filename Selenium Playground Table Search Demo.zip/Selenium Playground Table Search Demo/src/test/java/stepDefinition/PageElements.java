package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PageElements {
    WebDriver driver;

    // Locating elements on the page
    private By searchBox = By.id("task-table-filter");
    private By results = By.xpath("//table[@id='task-table']/tbody/tr");
    private By totalEntriesText = By.xpath("//div[@class='col-sm-6 col-md-6']/label");

    // Constructor
    public PageElements(WebDriver driver) {
        this.driver = driver;
    }

    // Methods to interact with the elements
    public void enterSearchText(String text) {
        WebElement searchBoxElement = driver.findElement(searchBox);
        searchBoxElement.clear();
        searchBoxElement.sendKeys(text);
    }

    public int getSearchResultsCount() {
        return driver.findElements(results).size();
    }

    public String getTotalEntriesText() {
        WebElement totalTextElement = driver.findElement(totalEntriesText);
        return totalTextElement.getText();
    }
}
