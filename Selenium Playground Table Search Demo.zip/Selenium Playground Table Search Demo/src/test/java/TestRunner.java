import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/resources/Features/SearchFunctionality.feature", // Path to your feature file
    glue = {"stepdefinitions"},  // Package where step definitions are located
    plugin = {"pretty", "html:target/cucumber-reports"}  // Cucumber report generation
)
public class TestRunner {
    // This class is empty because it's only used as a runner for Cucumber tests with JUnit
}
