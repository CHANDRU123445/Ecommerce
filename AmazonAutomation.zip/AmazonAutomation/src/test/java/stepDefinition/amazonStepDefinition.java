 package stepDefinition;

import static org.testng.Assert.fail;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class amazonStepDefinition {

	public WebDriver driver;
	private Scenario myScenario;
	private static final Logger lOGGER = LoggerFactory.getLogger(amazonStepDefinition.class);
	PageElements elements = new PageElements();
	String userDir = System.getProperty("user.dir");
	String screenshotPath=userDir+"\\ScreenShots";

	
	@Given("Launch the url {string}")
	public void launchTheUrl(String url) {
		driver.get(url);
	}


	@When("Click on {string} in the menu")
	public void clickOnProductInTheMenu(String menu) throws Exception {
		By product = By.xpath("//div[@id='hmenu-content']//li//a//div[contains(text(),\""+ menu +"\")]");
		if(driver.findElements(product).size()==0) {
			fail("Menu button not clicked");
		}
		Thread.sleep(2000);
		clickJSEon(product);
		By element = By.xpath("//div[@id='hmenu-content']//ul//li//a[contains(text(),\"" + menu + "\")]");
		try {
			waitForVisibilityOfElement(element, 10);
		} catch (Exception e) {
					clickOn(elements.menuBtn);
					clickJSEon(product);
		}
		clickJSEon(element);
	}

	@When("click on menu button")
	public void clickOnMenuButton() throws Exception {
		clickOn(elements.menuBtn);
//		captureAndSaveScreenshot(screenshotPath, "name");
//		takeScreenShot(screenshotPath);
	}

	@When("Filter by {string} star")
	public void filterByStar(String star) throws Exception {
		By review = By.xpath("//span[text()=\"Avg. Customer Review\"]/parent::div/following-sibling::ul//div//span[contains(text(),'"+star+"')]/parent::i");
		scrollToElement(review);
//		Thread.sleep(4000);
		clickOn(review);
		captureScreenShot();
	}

	@When("Filter by {string} price")
	public void filterByPrice(String amount) throws Exception {
		By review = By.xpath("//span[text()=\"Price\"]/parent::div/following-sibling::ul//span//li//a//span[contains(text(),\""+amount+"\")]");
		scrollToElement(review);
//		Thread.sleep(4000);
		clickOn(review);
	}

	@When("Select the brand {string} and {string}")
	public void selectTheBrandAnd(String product1, String product2) throws Exception {
		By brand1=By.xpath("//span[text()=\"Brand\"]/parent::div/following-sibling::ul//li[@aria-label='"+product1+"']//input");
		By brand2=By.xpath("//span[text()=\"Brand\"]/parent::div/following-sibling::ul//li[@aria-label='"+product2+"']//input");
		scrollToElement(brand1);
		clickJSEon(brand1);
		Thread.sleep(2000);
		clickJSEon(brand2);
	}

	@When("Count number of result")
	public void countNumberOfResult() throws Exception {
		waitForVisibilityOfElement(elements.imagecount);
		int imageCount=driver.findElements(elements.imagecount).size();
		System.out.println(imageCount);
		takeScreenShot("count the product count");
	}

	@When("Select the {string} product")
	public void selectTheProduct(String count) {
		By product=By.xpath("(//div[@class='s-image-padding'])["+count+"]");
		clickOn(product);
	}

	@When("Check the item is added to the cart")
	public void checkTheItemIsAddedToTheCart() throws Exception {
		switchToNewWindow();
		clickOn(elements.addToCartBtn);
		waitForVisibilityOfElement(elements.cartCount);
		String cartValue=driver.findElement(elements.cartCount).getText();
		System.out.println(cartValue);
		if(!cartValue.equalsIgnoreCase("1")) {
			fail("Item not added to the cart");
		}
		takeScreenShot("Cart");
	}

	private void waitForVisibilityOfElement(By visbleElement) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(visbleElement));
	}
	
	private void waitForVisibilityOfElement(By visbleElement,int sec) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(sec));
		wait.until(ExpectedConditions.visibilityOfElementLocated(visbleElement));
	}

	private void clickOn(By element) {
		waitForVisibilityOfElement(element);
		driver.findElement(element).click();
	}
	
	private void clickJSEon(By element) {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].click();", driver.findElement(element));
        
	}
	
	private void scrollToElement(By element) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(element));
    }
	
	private void switchToNewWindow() {
		String currentWindow = driver.getWindowHandle();
		Iterator<String> windows = driver.getWindowHandles().iterator();
		while (windows.hasNext()) {
			String window = windows.next();
			if (!currentWindow.equalsIgnoreCase(window)) {
				driver.switchTo().window(window);
				driver.manage().window().maximize();
				break;
			}
		}
	}
	
	@Before
	public void launchBrowser(Scenario scenario) throws Exception {
		myScenario = scenario;
		myScenario.getId();
		
		driver = new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

	}
	
	@After
	public void tearDown(Scenario scenario) throws Exception {
		if (scenario.isFailed()) {
			try {

//				takeScreenShot(" test is failed " + scenario.getUri());
				captureScreenShot();
			} catch (Exception e) {
			}
		}
//		driver.close();
//		driver.quit();

	}
	
	public void takeScreenShot(String ssName) throws Exception {
		try {
			byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            myScenario.attach(screenshot, "image/png", ssName);
		} catch (WebDriverException somePlatformsDontSupportScreenshots) {
			lOGGER.error("An error occurred while taking a screenshot:", somePlatformsDontSupportScreenshots);
		} catch (ClassCastException cce) {
		}
	}
	
	public void captureScreenShot() {
        try {
            Robot robot = new Robot();
            Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
            BufferedImage screenCapture = robot.createScreenCapture(screenRect);
            String filePath = ""+screenshotPath+"/screenshot.png";
            File screenshotFile = new File(filePath);
            ImageIO.write(screenCapture, "png", screenshotFile);

            System.out.println("Screenshot saved to: " + screenshotFile.getAbsolutePath());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
