package stepDefinition;

import org.openqa.selenium.By;

public class PageElements {
	
	public By menuBtn=By.id("nav-hamburger-menu");
	
	public By element3=By.xpath("//span[text()=\"Avg. Customer Review\"]/parent::div/following-sibling::ul//div//span[contains(text(),'4')]");
	
	public By element4=By.xpath("//span[text()=\"Price\"]/parent::div/following-sibling::ul//span//li//a//span[contains(text(),\"₹1,000 - ₹5,000\")]");
	public By puma=By.xpath("//span[text()=\"Brand\"]/parent::div/following-sibling::ul//li[@aria-label='Puma']//input");
	public By allenSolly=By.xpath("//span[text()=\"Brand\"]/parent::div/following-sibling::ul//li[@aria-label='Allen Solly']//input");
	public By imagecount=By.xpath("//div[@class='s-image-padding']");
	public By loading =By.xpath("//div[@id='loading']");
	public By addToCartBtn=By.id("add-to-cart-button");
	public By cartCount=By.xpath("//span[@id='nav-cart-count']");
}
