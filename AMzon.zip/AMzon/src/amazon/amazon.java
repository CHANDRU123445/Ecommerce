package amazon;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class amazon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new ChromeDriver();
		//Maximize current window
 driver.manage().window().maximize();
 driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
driver.get("https://www.amazon.in/");
WebElement SignIn_button = driver.findElement(By.xpath("//*[@id=\"nav-hamburger-menu\"]/i"));
SignIn_button.click();
WebElement sign = driver.findElement(By.id("hmenu-customer-name")); 
sign.click();
//Step 1: Input Invalid username and password
 WebElement usernameInput = driver.findElement(By.xpath("//*[@id=\"ap_email\"]"));
WebElement passwordInput = driver.findElement(By.xpath("//*[@id=\"continue\"]"));
//Step 2: Verify the login button functionality
 usernameInput.sendKeys("Amazon");
 passwordInput.click();
 //step3: Validate the Invalid fucntionality with error message
 String Capture = driver.findElement(By.id("auth-error-message-box")).getText();
 System.out.println(Capture);

 //Step 4 : Invalid data clear and enter the valid data
 WebElement usernameInput1 = driver.findElement(By.xpath("//*[@id=\"ap_email\"]"));
 usernameInput1.clear();
 WebElement usernameInput3 = driver.findElement(By.xpath("//*[@id=\"ap_email\"]"));
 usernameInput3.sendKeys("keyontae24@shehermail.com");
 WebElement passwordInput1 = driver.findElement(By.xpath("//*[@id=\"continue\"]"));
 passwordInput1.click();
 // passoword enter
 WebElement password = driver.findElement(By.xpath("//*[@id=\"ap_password\"]"));
 password.sendKeys("709415825");
 //login click
 WebElement signin = driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]"));
 signin.click();
 
	}

}
