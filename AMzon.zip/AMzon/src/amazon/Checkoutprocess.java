package amazon;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class Checkoutprocess {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		//Maximize current window
 driver.manage().window().maximize();
 driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
driver.get("https://www.amazon.in/");
		 // Step 1: Navigate to the checkout process from the shopping cart
        WebElement checkoutButton = driver.findElement(By.id("checkoutButton"));
        checkoutButton.click();

        // Step 2: Select shipping address
        WebElement addressInput = driver.findElement(By.id("address"));
        addressInput.sendKeys("123 Main Street");

        // Step 3: Select payment method
        WebElement paymentMethodDropdown = driver.findElement(By.id("paymentMethod"));
        paymentMethodDropdown.click();
        WebElement selectPaymentMethod = driver.findElement(By.xpath("//option[text()='Credit Card']"));
        selectPaymentMethod.click();


	}

}


///

